# NTK B39B4 - Four-arm local hybrid CLI

This package extends the runnable system, not the thesis report or slides.
It is a separate CLI comparison component. Production web 8766 and its receipts are NOT modified.

## Run on WSL

Activate the existing Conda iris environment and export NTK_IRIS_PYTHON.
Verify the package ZIP SHA before extraction. From a newly extracted directory:

```bash
bash run.sh --run-hybrid
```

The default input is samples/B39B4_JDK_INTEGRATION.zip: 16 new, synthetic JDK-only
Java files. These are integration examples, not a human-reviewed independent gold set.
Compilation does not execute their Java methods. Some examples contain intentionally
unsafe API use. Do not run the sample application code.

A local operator-selected ZIP may be provided with --project-zip /absolute/path.zip.
Scope remains Java 21, 1-24 Java files, no external dependencies or user build scripts.
This comparison mode requires compiler candidates for each of the four profiles.
It does not expand the production engine to arbitrary Maven/Spring/Servlet projects.
Only use source you trust to process; ZIP validation and -proc:none are NOT a full sandbox.

## New execution, not replay

* One genuine OpenGrep scan. The baseline uses only these results with neutral model evidence.
* One genuine NEW CodeQL Java database and one compiler identity/source extraction.
* One CWE79 contextual-policy query and compiler encoding audit, shared by three arms.
* Native IRIS Stage 3, with the inherited strict B33 provider/worker, runs Base, Epoch 1,
  then Epoch 2. Each gets the SAME compiler candidates, prompt/token inputs and generation
  configuration, but a distinct new cache. A second native pass checks warm-cache integrity.
* Each arm runs four model-only CodeQL flow queries. For 22/78/89 these model-derived
  qualified paths feed the unchanged semantic fusion. For 79 the model-only result stays
  separate and the same policy-qualified paths feed the neutral-AI policy fusion.
* Each finding is re-scored with the frozen V2.2 scorer and checked for equality.
  Every original OpenGrep record is retained unchanged in the full local result.

This shares common extraction to avoid rebuilding the same database three times.
It is NOT three independent cold end-to-end latency measurements. Per-command wall times,
model-load time, generation time and allocator VRAM are recorded; device-total VRAM and
OS-cold-cache latency are not claimed.

## Prerequisites and safety

Keep the successful B39B3 result ZIP in Windows Downloads, along with the original B33
archive. The model and adapters, original source P/G, source manifest, frozen IRIS commit,
C4 receipt and DPA Epoch1 receipt must remain available. The CLI checks those original
receipts as source/evidence integrity preconditions. It never issues a receipt for new arms.
CodeQL and exact packs must be locally available. No package/model download is attempted.
At least 4 GiB free is required; all prior runs are retained, so storage grows.
Do not run B37/B38 scans or training concurrently. B38/B39 cooperative locks are acquired,
and compute-process checks are made. No existing process is killed to free the GPU.

Inference uses local model bytes with trust_remote_code=False and the existing model-worker
INET seccomp guard. OpenGrep uses the existing scanner network guard. Local-only model
execution is NOT a claim of machine-wide network isolation. CodeQL uses the pinned local
CLI, local packs and environment flags disabling telemetry; a new global CodeQL socket
sandbox is not claimed.

All Git/source/scorer/dataset/model baselines remain unchanged. The only source patch is
the already-used Stage3-only provider patch applied to a NEW git-archive snapshot.
The B39B4 native driver differs from B39B3 in run naming and candidate-origin metadata;
the imported native Stage3 method, provider and worker are unchanged.

## Outputs

Run directory: $W/batch39b4_hybrid_runs/b39b4_<UTC>_<id>/

Full LOCAL machine-readable outputs:

* private/analysis/opengrep_only/result.json and report.sarif
* private/analysis/base/result.json and report.sarif
* private/analysis/epoch_1/result.json and report.sarif
* private/analysis/epoch_2/result.json and report.sarif

The result object includes a display view with REVIEW PRIORITY labels. Legacy numeric
score breakdowns are preserved. Legacy risk-description text is not a confirmation;
vulnerability_confirmed remains false. No production UI files are edited.

The audit ZIP is written directly to Windows Downloads. It contains root-level JSON
metadata, metrics/counts, hashes, timings and SHA256SUMS only. Source, raw prompts/responses,
raw OpenGrep matches, raw SARIF/BQRS, database and weights stay LOCAL in private/.
Do not upload private/. Metadata has local paths and is not approved for a public Git push.

Success: B39B4_FOUR_ARM_HYBRID_EXECUTION_COMPLETE, no blockers and four completed arms.
This proves execution/invariants on this input, NOT detection accuracy or independence.
No quality threshold is forced; model ABSTAIN and zero paths are retained faithfully.
Absence of a path is not a safety verdict. Native role labels are not gold labels.
Model-only XSS results are not replaced with policy labels and no XSS model gate is granted.

On BLOCKED, retain the run. Read OPENGREP_EXECUTION_STATE, CODEQL_DATABASE_STATE and
MODEL_EXECUTION_STATE. VERIFIED_COMPLETED_NATIVE_REQUESTS excludes partially failed arms;
partial observations remain in the private trace. Do not rerun everything immediately,
change checksums, install packages, or modify old gates. Share the audit ZIP and terminal
output. The wrapper controls its own subprocess groups; it never uses pkill or kills
unrelated jobs. No git reset/model rollback is necessary because baselines are not edited.

## Authoring validation

125 synthetic tests: 51 inherited data/runtime, 40 inherited native-controller,
33 hybrid invariants/failure-export tests, and one complete controller lifecycle with
FAKE backends. Test progress text may say "real" as it exercises the production control
flow; backend calls in that one authoring test are patched and NOT real CodeQL/GPU runs.
All 16 sample Java files were genuinely compiled with javac 21, -proc:none, --release 21.
The sample methods were NOT executed. Live NTK CodeQL/GPU validation of this new CLI
must be performed on the user's WSL; it was not performed in the authoring environment.
