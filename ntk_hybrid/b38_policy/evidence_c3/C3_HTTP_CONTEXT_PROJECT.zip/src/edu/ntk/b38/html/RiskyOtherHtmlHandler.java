package edu.ntk.b38.html;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import java.io.IOException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;

public final class RiskyOtherHtmlHandler implements HttpHandler {
    @Override public void handle(HttpExchange exchange) throws IOException {
        String value = URLDecoder.decode(exchange.getRequestURI().getRawQuery(), StandardCharsets.UTF_8);
        String responseText = "<p>" + value + "</p>";
        exchange.getResponseHeaders().set("Content-Type", "text/html; charset=UTF-8");
        exchange.sendResponseHeaders(200, 0);
        exchange.getResponseBody().write(responseText.getBytes(StandardCharsets.UTF_8));
        exchange.close();
    }
}
