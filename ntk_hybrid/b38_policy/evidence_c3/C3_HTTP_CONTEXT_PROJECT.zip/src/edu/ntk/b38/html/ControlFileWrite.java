package edu.ntk.b38.html;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

public final class ControlFileWrite implements HttpHandler {
    @Override public void handle(HttpExchange exchange) throws IOException {
        String input = URLDecoder.decode(exchange.getRequestURI().getRawQuery(), StandardCharsets.UTF_8);
        // This write is to a local file, not to the HTTP response body.
        try (OutputStream file = Files.newOutputStream(Path.of("ntk-c3-not-executed.txt"))) {
            file.write(input.getBytes(StandardCharsets.UTF_8));
        }
        exchange.getResponseHeaders().set("Content-Type", "text/html; charset=UTF-8");
        exchange.sendResponseHeaders(200, 0);
        exchange.getResponseBody().write("<h1>Fixed</h1>".getBytes(StandardCharsets.UTF_8));
        exchange.close();
    }
}
