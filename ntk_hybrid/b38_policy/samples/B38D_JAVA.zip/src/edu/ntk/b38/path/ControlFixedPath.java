package edu.ntk.b38.path;

import java.nio.file.Files;
import java.nio.file.Path;
import java.io.IOException;
public final class ControlFixedPath {
    public static String readReport() throws IOException {
        return Files.readString(Path.of("/srv/ntk/reports/daily.txt"));
    }
}
