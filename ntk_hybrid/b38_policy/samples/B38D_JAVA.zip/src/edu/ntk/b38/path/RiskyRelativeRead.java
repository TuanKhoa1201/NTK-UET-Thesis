package edu.ntk.b38.path;

import java.nio.file.Files;
import java.nio.file.Path;
import java.io.IOException;
public final class RiskyRelativeRead {
    public static String readReport() throws IOException {
        String requested = System.getenv("NTK_REPORT_NAME");
        Path base = Path.of("/srv/ntk/reports");
        Path selected = base.resolve(requested);
        return Files.readString(selected);
    }
}
