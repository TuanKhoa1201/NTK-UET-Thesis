package edu.ntk.b38.path;

import java.nio.file.Files;
import java.nio.file.Path;
import java.io.IOException;
public final class RiskyNormalizedRead {
    public static byte[] readReport() throws IOException {
        String requested = System.getenv("NTK_REPORT_NAME");
        Path selected = Path.of("/srv/ntk/reports").resolve(requested).normalize();
        return Files.readAllBytes(selected);
    }
}
