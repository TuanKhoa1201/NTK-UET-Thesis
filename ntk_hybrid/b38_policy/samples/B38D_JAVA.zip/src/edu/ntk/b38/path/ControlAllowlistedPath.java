package edu.ntk.b38.path;

import java.nio.file.Files;
import java.nio.file.Path;
import java.io.IOException;
public final class ControlAllowlistedPath {
    public static byte[] readReport() throws IOException {
        String requested = System.getenv("NTK_REPORT_KIND");
        String selected = "daily".equals(requested) ? "daily.txt" : "monthly.txt";
        return Files.readAllBytes(Path.of("/srv/ntk/reports").resolve(selected));
    }
}
