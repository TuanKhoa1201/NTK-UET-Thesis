package edu.ntk.b38.command;

import java.io.IOException;
public final class RiskyExecutable {
    public static Process executeJob() throws IOException {
        String command = System.getenv("NTK_JOB_COMMAND");
        return Runtime.getRuntime().exec(command);
    }
}
