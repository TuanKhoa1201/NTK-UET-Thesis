package edu.ntk.b38.command;

import java.io.IOException;
public final class ControlAllowlistedCommand {
    public static Process executeJob() throws IOException {
        String mode = System.getenv("NTK_JOB_MODE");
        String command = "date".equals(mode) ? "/usr/bin/date" : "/usr/bin/true";
        return Runtime.getRuntime().exec(command);
    }
}
