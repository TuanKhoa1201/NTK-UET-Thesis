package edu.ntk.b38.command;

import java.io.IOException;
public final class ControlFixedCommand {
    public static Process executeJob() throws IOException {
        return Runtime.getRuntime().exec("/usr/bin/true");
    }
}
