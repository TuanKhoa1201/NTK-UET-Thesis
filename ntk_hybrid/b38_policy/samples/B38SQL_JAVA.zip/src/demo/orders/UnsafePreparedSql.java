package demo.orders;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
public final class UnsafePreparedSql {
  public void scan(Connection connection) throws SQLException {
    String user = System.getenv("NTK_DEMO_INPUT");
    String sql = "SELECT id FROM orders WHERE tag='" + user + "'";
    PreparedStatement stmt = connection.prepareStatement(sql);
    stmt.executeQuery();
  }
}
