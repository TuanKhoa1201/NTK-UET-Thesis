package demo.orders;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.SQLException;
public final class SafeConstantSql {
  public void scan(Connection connection) throws SQLException {
    Statement stmt = connection.createStatement();
    stmt.executeQuery("SELECT id FROM orders WHERE status=1");
  }
}
