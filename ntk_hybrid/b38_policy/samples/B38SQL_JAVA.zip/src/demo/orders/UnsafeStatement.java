package demo.orders;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.SQLException;
public final class UnsafeStatement {
  public void scan(Connection connection) throws SQLException {
    String user = System.getenv("NTK_DEMO_INPUT");
    Statement stmt = connection.createStatement();
    stmt.executeQuery("SELECT id FROM orders WHERE tag='" + user + "'");
  }
}
