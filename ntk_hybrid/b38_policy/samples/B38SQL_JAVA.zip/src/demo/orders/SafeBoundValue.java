package demo.orders;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
public final class SafeBoundValue {
  public void scan(Connection connection) throws SQLException {
    String user = System.getenv("NTK_DEMO_INPUT");
    PreparedStatement stmt = connection.prepareStatement("SELECT id FROM orders WHERE tag=?");
    stmt.setString(1, user);
    stmt.executeQuery();
  }
}
