package edu.ntk.b38.html;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import java.io.IOException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
public final class ControlPlainText implements HttpHandler {
    @Override public void handle(HttpExchange exchange) throws IOException {
        String input = URLDecoder.decode(exchange.getRequestURI().getRawQuery(), StandardCharsets.UTF_8);
        String body = input;
        exchange.getResponseHeaders().set("Content-Type", "text/plain; charset=UTF-8");
        exchange.getResponseHeaders().set("X-Content-Type-Options", "nosniff");
        exchange.sendResponseHeaders(200, 0);
        exchange.getResponseBody().write(body.getBytes(StandardCharsets.UTF_8));
        exchange.close();
    }
}
